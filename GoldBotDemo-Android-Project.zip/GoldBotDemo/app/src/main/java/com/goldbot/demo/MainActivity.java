package com.goldbot.demo;

import android.app.Activity; import android.os.Bundle; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 TextView status,balance,log; Button botButton,tradeButton,resetButton; boolean botOn=false; double money=10000; int n=0;
 @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
  status=findViewById(R.id.status); balance=findViewById(R.id.balance); log=findViewById(R.id.log); botButton=findViewById(R.id.botButton); tradeButton=findViewById(R.id.tradeButton); resetButton=findViewById(R.id.resetButton);
  botButton.setOnClickListener(v->{botOn=!botOn; status.setText(botOn?"ربات دمو روشن است — پول واقعی درگیر نیست":"ربات دمو خاموش است"); botButton.setText(botOn?"خاموش کردن ربات":"روشن کردن ربات دمو");});
  tradeButton.setOnClickListener(v->{if(!botOn){Toast.makeText(this,"اول ربات دمو را روشن کن",Toast.LENGTH_SHORT).show();return;} n++; double pnl=(Math.random()-.45)*120; money+=pnl; balance.setText(String.format(Locale.US,"موجودی دمو: $%,.2f",money)); log.setText(String.format(Locale.US,"معامله دمو #%d\nنتیجه: %+.2f دلار\nموجودی: $%,.2f\n\n%s",n,pnl,money,log.getText()));});
  resetButton.setOnClickListener(v->{money=10000;n=0;botOn=false;balance.setText("موجودی دمو: $10,000.00");status.setText("حساب دمو فعال است");botButton.setText("روشن کردن ربات دمو");log.setText("هنوز معامله‌ای ثبت نشده است.");});
 }
}
